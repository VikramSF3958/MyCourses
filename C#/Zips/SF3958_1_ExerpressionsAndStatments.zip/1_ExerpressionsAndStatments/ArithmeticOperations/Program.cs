﻿namespace ArithmeticOperations;

class Program 
{
    public static void Main(string[] args)
    {
        Operations obj = new Operations();

        obj.Addition();
        obj.Division();
        obj.Mulitplication();
        obj.Modulous();
        obj.Subtraction();
    }
}