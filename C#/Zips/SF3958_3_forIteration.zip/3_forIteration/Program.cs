﻿namespace _3_forIteration
{
    class Program 
    {
        public static void Main(string[] args)
        {
            Action obj = new Action();
            obj.Operation();
            
        }
    }
}