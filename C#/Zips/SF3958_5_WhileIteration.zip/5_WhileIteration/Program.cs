﻿namespace _5_WhileIteration;

class Program 
{
    public static void Main(string[] args)
    {
        Action obj = new Action();
        obj.Operartion();
    }
}