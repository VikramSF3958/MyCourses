﻿namespace _6_StringManipulation;

class Program 
{
    public static void Main(string[] args)
    {
        Action obj = new Action();
        obj.Operation();
    }
}